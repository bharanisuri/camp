<?php /*db connection*/
session_start();
require '../db/dbcon.php';
require 'navbar.php';
if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
{
 header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Companies</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/popper.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/view.css">
</head>

<body>
<div class="table-responsive"><!--query-->
  <?php
     $query="select * from company";
     $runquery=mysqli_query($con,$query);
  ?>
  <table class="table">
    <thead class="thead-dark"><!-- table heading-->
      <tr>
        <th scope="col">Name</th>
        <th scope="col">  </th>
      </tr>
    </thead>
    <tbody><!--table body--> 
      <?php
        if(mysqli_num_rows($runquery)>0)/*fetching reach row*/
        {
          while($row=mysqli_fetch_assoc($runquery))
          {
            ?>
            <tr>
              <td><?php echo $row['name']; ?></td>
              <td>
              <form action="code.php" method="post">
                 <input type="hidden" name="app" value="<?php echo $row['cid']; ?>">
                 <button type="submit" class="btn btn-primary"name="apply" >Apply</button>
              </form>
            </td>
            </tr>
          <?php
          }
        }
        
        else{ echo "no data";}
      ?>
      
    </tbody>
</table>
</div>
</body>
</html>
