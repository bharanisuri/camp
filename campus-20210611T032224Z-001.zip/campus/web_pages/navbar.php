<!--entire code is only for navigation bar-->

<!DOCTYPE html>
<html lang="en">
<head>
    <title>DASHBOARD</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
</head>

<body><!--nav bar starting-->
<nav class="navbar sticky-top  navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="resume.php">My Profile</a>
        <a class="navbar-brand" href="view.php">View Companies</a>
        <a class="navbar-brand" href="view_applied.php">Applied Companies</a>
        <a class="navbar-brand" href="../index.php">Logout</a>
      </div>
    </nav><!--nav bar ending-->
    
</body>
</html>