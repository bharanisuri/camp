<?php   //connection code
   session_start();
   require '../db/dbcon.php';
   if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
  {
    header('location:login.php');
  }
?>
<?php // code for fixed navbar
   require 'navbar.php';
?>
<html lang="en">
<head>
    <title>COMPANIES</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
</head>
<body>
    
<div class="panel-group">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse1">Collapsible panel</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
      <div class="panel-body">Panel Body</div>
      <div class="panel-footer">Panel Footer</div>
    </div>
  </div>
</div>
    
</body>
</html>