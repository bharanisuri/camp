<?php /*db connection*/
session_start();
require '../db/dbcon.php';


if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
{
 header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>APPLY</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/popper.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/code.css">
</head>
<body>
  <?php
    $cid=$_POST['app'];
    $query="select * from company where cid=$cid";
    $runquery=mysqli_query($con,$query);
    $data=mysqli_fetch_assoc($runquery);
  ?>
  <nav class="navbar sticky-top  navbar-light bg-light" width="1200" height="50">
      <div class="container-fluid">
       
      </div>
    </nav><!--nav bar ending-->

  <div class="container"><!--display company details-->
      <h1 style="color:white">Company details <br> </h1><hr>
      <h2><b>Name: </b><?php echo $data['name']; ?></h2>
      <h2><b>Description: </b><?php echo $data['description']; ?></h2>
      <h2><b>Email: </b><?php echo $data['email']; ?></h2>
      <h2><b>Phone: </b><?php echo $data['phone']; ?></h2>
      <h2><b>Location: </b><?php echo $data['location']; ?></h2>
      <h2><b>Job Role: </b><?php echo $data['role']; ?></h2>
      <h2><b>Salary: </b><?php echo $data['salary']; ?></h2>
      <h3 style="font-size:39px">Eligibility</h3>
      <h2><b>10th Percentage: </b><?php echo $data['cut_10']; ?><h2>
      <h2><b>12th Percentage: </b><?php echo $data['cut_12']; ?><h2>
      <h2><b>Degree Percentage: </b><?php echo $data['cut_deg']; ?><h2>
      <h2><b>Backlogs allowed: </b><?php echo $data['deg_backlogs']; ?></h2>
      <br><br>

      <form action="apply.php" method="post">
        <input type="hidden" name="app" value="<?php echo $data['cid']; ?>">
        <button type="submit" class="btn btn-primary"name="apply" >Apply</button>
      </form>
  </div>
</body>
</html>



