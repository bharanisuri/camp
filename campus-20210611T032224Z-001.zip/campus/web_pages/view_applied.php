<?php /*db connection*/
session_start();
require '../db/dbcon.php';
require 'navbar.php';

if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
{
 header('location:login.php');
}
$usn=$_SESSION['sid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>APPLIED COMPANIES</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/popper.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/applied.css">
</head>
<body>
<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">Company Name</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $query="select * from applied";
    $runquery=mysqli_query($con,$query);
    if(mysqli_num_rows($runquery)>0)
    {
      while($row=mysqli_fetch_assoc($runquery))
      {
        if($row['sid']==$usn)
        {
            $cid=$row['cid'];
            $q="select name from company where cid=$cid";
            $res=mysqli_query($con,$q);
            if(mysqli_num_rows($res)>0) 
            {
                $data=mysqli_fetch_assoc($res);
                echo "<tr><td>".$data['name']."</td></tr>";
            }
        }
      }
    }
    else
    {
        echo "no data";
    }
   ?>
  </tbody>
</table>
</body>
</html>
